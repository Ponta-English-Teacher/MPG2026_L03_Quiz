// ============================================================
//  MPG2026 – L01 Question Bank
//  Edit this file to update or add questions for future lessons.
// ============================================================

const QUIZ_META = {
  courseID: "MPG2026",
  lessonID: "L01",
  quizID:   "MPG2026_L01",
  title:    "Modern Pronunciation and Grammar 2026",
  subtitle: "Orientation Quiz – Lesson 1",
};

// Section definitions (used for result breakdown)
const SECTIONS = [
  { name: "Part of Speech by Function", questions: [1,2,3,4,5,6,7,8] },
  { name: "Function in a Sentence",     questions: [9,10,11,12,13,14] },
  { name: "Structure Awareness",        questions: [15,16,17,18,19] },
  { name: "Drag and Drop",              questions: [20,21,22,23,24] },
  { name: "Dictation",                  questions: [25,26,27,28] },
  { name: "Dictation + Analysis",       questions: [29,30] },
];

// Comment bands (score out of 30)
const COMMENT_BANDS = [
  { min: 27, max: 30, comment: "Excellent work. You have a strong understanding of basic grammar functions." },
  { min: 23, max: 26, comment: "Good job. You understand many important points. Keep building your accuracy." },
  { min: 18, max: 22, comment: "Nice try. You have a good start, but you need more practice with sentence structure and word function." },
  { min: 13, max: 17, comment: "Keep working. You understand some basics, but you need more practice to read and hear sentences accurately." },
  { min:  0, max: 12, comment: "Work harder next time. Focus on part of speech, sentence structure, and listening carefully." },
];
const CLOSING_NOTE = "Grammar helps you understand meaning and listening more accurately. Keep going.";

// ============================================================
//  Question data
//  type: "mc" | "dragdrop" | "dictation" | "dictation_analysis"
// ============================================================
const QUESTIONS = [
  // ── Section 1: Part of Speech by Function ──────────────────
  {
    id: 1, section: 1, type: "mc",
    stem: "A word that names a person, place, thing, or idea is called a:",
    options: { A: "verb", B: "noun", C: "adverb" },
    correct: "B",
    explanation: "A noun names a person, place, thing, or idea.",
  },
  {
    id: 2, section: 1, type: "mc",
    stem: "A word that expresses an action or state is called a:",
    options: { A: "adjective", B: "verb", C: "preposition" },
    correct: "B",
    explanation: "A verb shows an action or state.",
  },
  {
    id: 3, section: 1, type: "mc",
    stem: "A word that describes a noun is called a:",
    options: { A: "adjective", B: "adverb", C: "conjunction" },
    correct: "A",
    explanation: "An adjective modifies a noun.",
  },
  {
    id: 4, section: 1, type: "mc",
    stem: "A word that modifies a verb, adjective, or whole sentence is called a:",
    options: { A: "noun", B: "adverb", C: "pronoun" },
    correct: "B",
    explanation: "An adverb modifies a verb, adjective, or sentence.",
  },
  {
    id: 5, section: 1, type: "mc",
    stem: "A word that connects a noun to another element and shows a relationship such as time, place, or direction is called a:",
    options: { A: "preposition", B: "adjective", C: "interjection" },
    correct: "A",
    explanation: "A preposition shows relationships such as place, time, and direction.",
  },
  {
    id: 6, section: 1, type: "mc",
    stem: "A word that replaces a noun is called a:",
    options: { A: "determiner", B: "pronoun", C: "adverb" },
    correct: "B",
    explanation: "A pronoun takes the place of a noun.",
  },
  {
    id: 7, section: 1, type: "mc",
    stem: "A word that comes before a noun and identifies or limits it is called a:",
    options: { A: "determiner", B: "conjunction", C: "verb" },
    correct: "A",
    explanation: "A determiner limits or identifies a noun.",
  },
  {
    id: 8, section: 1, type: "mc",
    stem: "A word that connects words, phrases, or clauses is called a:",
    options: { A: "preposition", B: "conjunction", C: "noun" },
    correct: "B",
    explanation: "A conjunction connects words, phrases, or clauses.",
  },

  // ── Section 2: Function in a Sentence ──────────────────────
  {
    id: 9, section: 2, type: "mc",
    stem: "In <em>She quickly finished her homework</em>, what is <em>quickly</em>?",
    options: { A: "adjective", B: "adverb", C: "noun" },
    correct: "B",
    explanation: "It modifies the verb <em>finished</em>.",
  },
  {
    id: 10, section: 2, type: "mc",
    stem: "In <em>She is kind</em>, what is <em>kind</em>?",
    options: { A: "object", B: "adverb", C: "complement" },
    correct: "C",
    explanation: "It describes the subject after the linking verb.",
  },
  {
    id: 11, section: 2, type: "mc",
    stem: "In <em>The tall student answered the question</em>, what is <em>tall</em>?",
    options: { A: "adjective", B: "adverb", C: "noun" },
    correct: "A",
    explanation: "It describes the noun <em>student</em>.",
  },
  {
    id: 12, section: 2, type: "mc",
    stem: "In <em>He answered the question correctly</em>, what is <em>correctly</em>?",
    options: { A: "adjective", B: "adverb", C: "complement" },
    correct: "B",
    explanation: "It modifies the verb <em>answered</em>.",
  },
  {
    id: 13, section: 2, type: "mc",
    stem: "In <em>He gave her a book</em>, what is <em>her</em>?",
    options: { A: "subject", B: "object", C: "complement" },
    correct: "B",
    explanation: "It functions as an object in the sentence.",
  },
  {
    id: 14, section: 2, type: "mc",
    stem: "In <em>She made him happy</em>, what is <em>happy</em>?",
    options: { A: "object", B: "complement", C: "adverb" },
    correct: "B",
    explanation: "It describes the object <em>him</em>.",
  },

  // ── Section 3: Structure Awareness ─────────────────────────
  {
    id: 15, section: 3, type: "mc",
    stem: "In <em>The book on the table is mine</em>, what is the main subject?",
    options: { A: "book", B: "table", C: "mine" },
    correct: "A",
    explanation: "<em>Book</em> is the core subject.",
  },
  {
    id: 16, section: 3, type: "mc",
    stem: "In <em>The book on the table is mine</em>, what is the whole subject?",
    options: { A: "The book", B: "The book on the table", C: "on the table" },
    correct: "B",
    explanation: "The whole subject includes the noun and its modifier.",
  },
  {
    id: 17, section: 3, type: "mc",
    stem: "In <em>The students in the classroom are studying</em>, what is the main subject?",
    options: { A: "students", B: "classroom", C: "studying" },
    correct: "A",
    explanation: "<em>Students</em> is the core subject.",
  },
  {
    id: 18, section: 3, type: "mc",
    stem: "In <em>The baby is sleeping</em>, what is the predicate?",
    options: { A: "The baby", B: "is sleeping", C: "sleeping" },
    correct: "B",
    explanation: "The predicate tells what the subject does or is.",
  },
  {
    id: 19, section: 3, type: "mc",
    stem: "In <em>She made him happy</em>, what is the object?",
    options: { A: "she", B: "him", C: "happy" },
    correct: "B",
    explanation: "<em>Him</em> receives the action.",
  },

  // ── Section 4: Drag and Drop ────────────────────────────────
  {
    id: 20, section: 4, type: "dragdrop",
    instruction: "Arrange the words to make a correct sentence.",
    blocks: ["The student", "reads", "a book"],
    correct: ["The student", "reads", "a book"],
  },
  {
    id: 21, section: 4, type: "dragdrop",
    instruction: "Arrange the words to make a correct sentence.",
    blocks: ["She", "is", "happy"],
    correct: ["She", "is", "happy"],
  },
  {
    id: 22, section: 4, type: "dragdrop",
    instruction: "Arrange the words to make a correct sentence.",
    blocks: ["She", "quickly", "finished", "her homework"],
    correct: ["She", "quickly", "finished", "her homework"],
  },
  {
    id: 23, section: 4, type: "dragdrop",
    instruction: "Arrange the words to make a correct sentence.",
    blocks: ["The book", "on the table", "is", "mine"],
    correct: ["The book", "on the table", "is", "mine"],
  },
  {
    id: 24, section: 4, type: "dragdrop",
    instruction: "Arrange the words to make a correct sentence.",
    blocks: ["She", "made", "him", "happy"],
    correct: ["She", "made", "him", "happy"],
  },

  // ── Section 5: Dictation ────────────────────────────────────
  {
    id: 25, section: 5, type: "dictation",
    audio: "audio/q25.mp3",
    correct: "The student reads a book",
    note: "This is a basic SVO sentence.",
  },
  {
    id: 26, section: 5, type: "dictation",
    audio: "audio/q26.mp3",
    correct: "She is very happy",
    note: "This sentence uses a complement after a linking verb.",
  },
  {
    id: 27, section: 5, type: "dictation",
    audio: "audio/q27.mp3",
    correct: "They gave him a gift",
    note: "This sentence includes two objects.",
  },
  {
    id: 28, section: 5, type: "dictation",
    audio: "audio/q28.mp3",
    correct: "She quickly finished her homework",
    note: "The adverb helps show how the action happens.",
  },

  // ── Section 6: Dictation + Analysis ────────────────────────
  {
    id: 29, section: 6, type: "dictation_analysis",
    audio: "audio/q29.mp3",
    correct: "The book sold in the store doesn't sell well",
    analysisQuestion: "What is <em>sold</em>?",
    options: { A: "main verb", B: "adjective modifying book", C: "noun" },
    correctAnalysis: "B",
    explanation: "<em>Sold in the store</em> describes <em>book</em>.",
    note: "Listen carefully to distinguish the two uses of <em>sell/sold</em>.",
  },
  {
    id: 30, section: 6, type: "dictation_analysis",
    audio: "audio/q30.mp3",
    correct: "The man standing by the door is my teacher",
    analysisQuestion: "What is <em>standing</em>?",
    options: { A: "main verb", B: "adjective modifying man", C: "noun" },
    correctAnalysis: "B",
    explanation: "<em>Standing by the door</em> describes <em>man</em>.",
    note: "Listen for the participial phrase that modifies the subject.",
  },
];
